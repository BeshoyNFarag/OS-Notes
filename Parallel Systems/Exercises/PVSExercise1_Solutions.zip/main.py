# from typing import List, Optional, Union

from animal import Animal
from giraffe import Giraffe
from pig import Pig

number_of_animals = 0

def createGiraffe(name: str, age: int, height: float) -> Giraffe:
    global number_of_animals
    number_of_animals += 1
    return Giraffe(name, age, height)

def createPig(name: str, age: int, weight: float) -> Pig:
    global number_of_animals
    number_of_animals += 1
    return Pig(name, age, weight)

# def readPigsFromFile(path: str) -> List[Pig]:
def readPigsFromFile(path: str) -> list[Pig]:
    result = []
    with open(path) as file:
        for line in file:
            entries = line.split(',')
            name = entries[0]
            age = int(entries[1])
            weight = float(entries[2])
            result.append(createPig(name, age, weight))
    return result

# def returnAninalWithName(animal_list: List[Animal], name: str) -> Optional[Animal]:
# def returnAninalWithName(animal_list: List[Animal], name: str) -> Union[Animal, None]:
def returnAnimalWithName(animal_list: list[Animal], name: str) -> Animal | None:
    for animal in animal_list:
        if animal.name == name:
            return animal
    return None

# def getAnimalsOlderThan(animal_list: List[Animal], age: Union[int, str]) -> List[Animal]:
def getAnimalsOlderThan(animal_list: list[Animal], age: int | str) -> list[Animal]:
    # if type(age) == str:
    # if isinstance(age, str):
    if age is str:
        age = int(age)
    return [a for a in animal_list if a.age > age]

if __name__ == '__main__':
    animals = []
    for i in range(10):
        g = createGiraffe(f'Giraffe{i}', i, 4.3)
        g.speak()
        p = createPig(f'Pig{i}', i,  65.3)
        p.speak()
        animals.extend([g, p])
    animals.extend(readPigsFromFile('pigs.data'))
    print(f'Number of animals: {number_of_animals}')
    pigA = returnAnimalWithName(animals, 'PigA')
    print(pigA.age)
    old_animals = getAnimalsOlderThan(animals, 2)
    for a in old_animals:
        print(a.name)