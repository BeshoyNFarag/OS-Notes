from animal import Animal


class Pig(Animal):
    def __init__(self, name: str, age: int, weight: float):
        if age < 0 or weight < 0:
            raise ValueError('Age and weight must be positive')
        super().__init__(name, age)
        self.weight = weight

    def speak(self) -> None:
        super().speak()
        print(f'I am a pig, my weight is {self.weight}')