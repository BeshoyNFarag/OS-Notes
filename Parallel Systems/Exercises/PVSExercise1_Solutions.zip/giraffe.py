from animal import Animal


class Giraffe(Animal):
    def __init__(self, name, age, height):
        super().__init__(name, age)
        self.height = height

    def speak(self):
        super().speak()
        print(f'I am a giraffe, my height is {self.height}')